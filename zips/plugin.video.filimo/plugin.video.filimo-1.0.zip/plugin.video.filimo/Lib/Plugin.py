﻿# -*- coding: utf-8 -*-
import sys
import json
import requests
from urllib.parse import urlencode
from urllib.parse import quote_plus
from urllib.parse import parse_qsl
import re
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import random

# Disable urllib3's "InsecureRequestWarning: Unverified HTTPS request is being made" warnings.
requests.packages.urllib3.disable_warnings(
    requests.packages.urllib3.exceptions.InsecureRequestWarning
)

Addon = xbmcaddon.Addon()
token = Addon.getSetting('token')

try:
    PLUGIN_ID = int(sys.argv[1])
    PLUGIN_URL = sys.argv[0]
except:
    pass


def action_search_filimo(params):
    searchstring = str(xbmcgui.Window(10000).getProperty('SearchText'))
    searchchar = str(xbmcgui.Window(10000).getProperty('SearchTextChar'))
    if (searchchar == ''):
        return
    elif searchchar[0] == ';':  # Delete
        searchstring = searchstring[0:-1]
        if (searchstring == ''):
            xbmcgui.Window(10000).setProperty('SearchText', searchstring)
            return
    elif searchchar[0] == '-':  # Space
        searchstring = searchstring + ' '
    elif searchchar[0] == '@':
        pass
    else:
        searchstring = searchstring + searchchar
    xbmcgui.Window(10000).setProperty('SearchText', searchstring)
    xbmcgui.Window(10000).setProperty('SearchTextChar', '@')

    xbmc.executebuiltin(
        "AlarmClock(SearchLiveType,SetProperty(SearchLiveType," + searchstring + ",home),00:04,silent,false)")


def keyboard(heading):
    text = None
    keyboard = xbmc.Keyboard("", heading=heading)
    keyboard.setHeading(heading)  # optional
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        text = keyboard.getText()
    del keyboard
    return text


def search_movie_byplugin(params):
    search_text = keyboard("جستجو")
    if search_text is None:
        return
    obj = {'LiveText': search_text}
    search_filimo_get_content(obj)


def action_main_page_plugin():
    xbmcplugin.setContent(PLUGIN_ID, 'episodes')
    xbmcplugin.addDirectoryItems(PLUGIN_ID, [
        (build_url({'action': 'get_home_content'}), make_list_item("خانه"), True),
        (build_url({'action': 'search_movie_byplugin'}), make_list_item("جستجو"), True),
        (build_url({'action': 'login_to_filimo_by_plugn'}), make_list_item("ورود به فیلیمو"), True),
    ])
    xbmcplugin.endOfDirectory(PLUGIN_ID)


def search_filimo_get_content(param):
    def _episodesItemsGen():
        r = requests.get('https://www.filimo.com/etc/api/search/text/' + param['LiveText'], timeout=10, verify=False)
        r = r.json()
        showsData = r['search']
        if (showsData == None):
            return

        for i in range(0, min(len(showsData), 8)):
            label = showsData[i]['movie_title']
            Thumb = showsData[i]['movie_img_m']
            uid = showsData[i]['uid']
            if (uid == None):
                continue
            item = make_list_item(
                label,
                {
                    'title': label,
                },
                Thumb
            )
            itemURL = build_url(
                {
                    'action': 'action_single_movie',
                    'route': showsData[i]['uid'],
                }
            )
            yield (itemURL, item, True)

    xbmcplugin.addDirectoryItems(PLUGIN_ID, tuple(_episodesItemsGen()))
    xbmcplugin.endOfDirectory(PLUGIN_ID)


def action_single_movie(params):
    xbmcplugin.setContent(PLUGIN_ID, 'movies')

    def _episodesItemsGen():
        r = requests.get('https://www.filimo.com/_/api/fa/v1/movie/movie/one/uid/' + params['route'], timeout=10,
                         verify=False)
        r = r.json()
        showsData = r['data']['attributes']['General']
        title = showsData['title']
        plot = showsData['descr']
        plot = plot.replace('…', '...')
        thumb = showsData['thumbnails']['movie_img_b']

        genre = ''
        if showsData['categories'] != None:
            for item in showsData['categories']: genre = genre + item['title'] + ' - '

        director = ''
        if showsData['director'] != None:
            for item in showsData['director']: director = director + item['name'] + ' - '

        tagline = showsData['movie_detail'].replace('-', '[COLOR=ffffb000] | [/COLOR]')
        item = make_list_item(
            title,
            {
                'title': title,
                'plot': plot,
                'genre': genre[:-2],
                'director': director[:-2],
                'tagline': tagline,
                'rating': showsData['imdb_rate'] * 2
            },
            thumb
        )
        item.setProperty('IsPlayable', 'true')  # Allows the checkmark to be placed on watched episodes.
        item.setProperty('IsSerial',
                         str(showsData['serial']['enable']))  # Allows the checkmark to be placed on watched episodes.
        itemURL = build_url(
            {
                'action': 'action_play',
                'route': showsData['uid'],
            }
        )
        item.setProperty('movieuid', showsData['uid'])  # Allows the checkmark to be placed on watched episodes.
        yield (itemURL, item, False)

        r = requests.get('https://www.filimo.com/etc/api/recom/uid/' + showsData['uid'], timeout=10, verify=False)
        r = r.json()
        recom = r['recom']

        for i in range(0, len(recom)):
            item = make_list_item(
                recom[i]['movie_title'],
                {
                    'title': recom[i]['movie_title'],
                },
                recom[i]['movie_img_m']
            )
            itemURL = build_url(
                {
                    'action': 'action_single_movie',
                    'route': recom[i]['uid'],
                }
            )
            yield (itemURL, item, True)

    xbmcplugin.addDirectoryItems(PLUGIN_ID, tuple(_episodesItemsGen()))
    xbmcplugin.endOfDirectory(PLUGIN_ID)


def action_get_more_movie(param):
    xbmcplugin.setContent(PLUGIN_ID, 'videos')
    r = requests.get('https://www.filimo.com/_/api/fa/v1/movie/movie/list/tagid/' + param['tagid'], timeout=10,
                     verify=False)
    r = r.json()
    data = r['data']
    include = r['included']
    rowdata = data[0]['relationships']['movies']['data']

    def _temsGen():
        x = 0
        y = 0
        for j in range(0, len(rowdata)):
            movieid = rowdata[j]['id']
            y = x
            while include[y]['id'] != movieid:
                y = y - 1
            moviedata = include[y]['attributes']
            if x == y:
                x = x + 1
            item = make_list_item(
                moviedata['movie_title'],
                {
                    'title': moviedata['movie_title'],
                    'episode': j  # for ID to detect movie
                },
                moviedata['pic']['movie_img_m']
            )
            itemURL = build_url(
                {
                    'action': 'action_single_movie',
                    'route': moviedata['uid'],
                }
            )
            yield (itemURL, item, True)

    xbmcplugin.addDirectoryItems(PLUGIN_ID, tuple(_temsGen()))
    xbmcplugin.endOfDirectory(PLUGIN_ID)


def action_get_episode_of_uid_movie(param):
    xbmcplugin.setContent(PLUGIN_ID, 'episodes')

    r = requests.get('https://www.filimo.com/_/api/fa/v1/movie/movie/one/uid/' + param['uid'], timeout=10, verify=False)
    r = r.json()
    serialTitle = r['data']['attributes']['General']['serial']['title']

    r = requests.get('https://www.filimo.com/etc/api/movieserial/uid/' + param['uid'], timeout=10, verify=False)
    r = r.json()
    movieserial = r['movieserial']

    def _episodesItemsGen():
        for i in range(0, len(movieserial)):
            uid = movieserial[i]['uid']
            title = movieserial[i]['movie_title']
            episodeThumb = movieserial[i]['movie_img_b']
            item = make_list_item(
                title,
                {
                    'title': serialTitle,
                    'duration': movieserial[i]['duration_sec']
                },
                episodeThumb
            )
            item.setProperty('movieuid', uid)  # Allows the checkmark to be placed on watched episodes.
            itemURL = build_url(
                {
                    'action': 'action_single_movie',
                    'route': uid,
                }
            )
            yield (itemURL, item, True)

    xbmcplugin.addDirectoryItems(PLUGIN_ID, tuple(_episodesItemsGen()))
    xbmcplugin.endOfDirectory(PLUGIN_ID)


def action_logout_filimo(params):
    requests.get('https://www.filimo.com/authentication/authentication/signout', headers={'Cookie': 'AuthV1=' + token},
                 timeout=10, verify=False)


def login_to_filimo(params):
    cwin = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    username = cwin.getControl(1).getText()
    password = cwin.getControl(5).getText()
    auth = ''
    if xbmcgui.Window(xbmcgui.getCurrentWindowId()).getProperty('otp') != 'yes':
        r = requests.get('https://www.filimo.com/_/login', timeout=10, verify=False)
        x = re.findall("""guid: "(.*?)",""", r.text)
        guid = x[0]
        obj = {"guid": guid}
        response = requests.post("https://www.filimo.com/api/fa/v1/user/Authenticate/auth/", data=obj)
        response = response.json()
        tempid = int(response['data']['attributes']['temp_id'])

        obj = {
            "guid": guid,
            "temp_id": tempid,
            "codepass_type": params['workon'],
            "account": username
        }
        response = requests.post("https://www.filimo.com/api/fa/v1/user/Authenticate/signin_step1", data=obj)
        response = response.json()
        auth = ''
        name = ''
        try:
            tempid = int(response['data']['attributes']['temp_id'])
            if params['workon'] == 'pass':
                obj = {"account": username, "code": password, "codepass_type": "pass", "guid": guid, "temp_id": tempid}
                response = requests.post("https://www.filimo.com/api/fa/v1/user/Authenticate/signin_step2", data=obj)
                response = response.json()
                auth = response['data']['attributes']['token']
                name = response['data']['attributes']['username']
            elif params['workon'] == 'otp':
                xbmcgui.Window(xbmcgui.getCurrentWindowId()).setProperty('notif',
                                                                         response['data']['attributes']['notif_text'])
                xbmcgui.Window(xbmcgui.getCurrentWindowId()).setProperty('tempid', str(tempid))
                xbmcgui.Window(xbmcgui.getCurrentWindowId()).setProperty('otp', 'yes')
                xbmcgui.Window(xbmcgui.getCurrentWindowId()).setProperty('guid', str(guid))

        except:
            xbmcgui.Window(xbmcgui.getCurrentWindowId()).setProperty('notif', response['errors'][0]['detail'])
    elif xbmcgui.Window(xbmcgui.getCurrentWindowId()).getProperty('otp') == 'yes':
        try:
            guid = xbmcgui.Window(xbmcgui.getCurrentWindowId()).getProperty('guid')
            tempid = xbmcgui.Window(xbmcgui.getCurrentWindowId()).getProperty('tempid')
            obj = {"account": username, "code": password, "codepass_type": "otp", "guid": guid, "temp_id": tempid}
            response = requests.post("https://www.filimo.com/api/fa/v1/user/Authenticate/signin_step2", data=obj)
            response = response.json()
            auth = response['data']['attributes']['token']
            name = response['data']['attributes']['username']
        except:
            xbmcgui.Window(xbmcgui.getCurrentWindowId()).setProperty('notif', response['errors'][0]['detail'])

    if auth != '':
        Addon.setSetting(id='token', value=auth)
        global token
        token = auth
        xbmc.executebuiltin("Skin.SetBool(LogedIn,true)")
        xbmc.executebuiltin("ReplaceWindow(Home)")


def login_to_filimo_by_plugn(param):
    global token
    if token != '':
        if not xbmcgui.Dialog().yesno("هشدار", "شما قبلا وارد شده اید آیا قصد دارید دوباره وارد شوید؟"):
            return

    username = keyboard("لطفا شماره تلفن همراه خود را وارد کنید")
    if username is None:
        return
    r = requests.get('https://www.filimo.com/_/login', timeout=10, verify=False)
    x = re.findall("""guid: "(.*?)",""", r.text)
    guid = x[0]
    obj = {"guid": guid}
    response = requests.post("https://www.filimo.com/api/fa/v1/user/Authenticate/auth/", data=obj)
    response = response.json()
    tempid = int(response['data']['attributes']['temp_id'])

    obj = {
        "guid": guid,
        "temp_id": tempid,
        "codepass_type": "otp",
        "account": username
    }
    response = requests.post("https://www.filimo.com/api/fa/v1/user/Authenticate/signin_step1", data=obj)
    response = response.json()
    try:
        tempid = int(response['data']['attributes']['temp_id'])
    except:
        notification(response['errors'][0]['detail'])

    password = keyboard("رمز عبور یکبار مصرف ارسال شده به شماره خود را وارد کنید")
    if password is None:
        return
    obj = {"account": username, "code": password, "codepass_type": "otp", "guid": guid, "temp_id": tempid}
    response = requests.post("https://www.filimo.com/api/fa/v1/user/Authenticate/signin_step2", data=obj)
    response = response.json()

    try:
        auth = response['data']['attributes']['token']
        name = response['data']['attributes']['username']

        if auth != '':
            Addon.setSetting(id='token', value=auth)
            token = auth
            notification("ورود به فیلیمو با موفقیت انجام شد")
    except:
        notification("مشکلی در ورود به فیلیمو رخ داده است. لطفا مجددا تلاش کنید")


def action_play(params):
    if token == '':
        notification('مشکل در تشخیص هویت لطفا مجددا وارد شوید')
    else:
        r = requests.get(
            'https://www.filimo.com/_/api/fa/v1/movie/movie/one/uid/' + params['route'],
            headers={'Cookie': 'AuthV1=' + token}, timeout=10, verify=False
        )
        data = r.json()

        if data['data']['attributes']['watch_action']['type'] == 'watch':
            qurl = data['data']['attributes']['watch_action']['movie_src']
            subtitle = data['data']['attributes']['General']['subtitle']
            doubled = data['data']['attributes']['General']['dubbed']

            item = make_list_item(
                xbmc.getInfoLabel('ListItem.Title'),
                {
                    'title': xbmc.getInfoLabel('ListItem.Title'),
                    'plot': xbmc.getInfoLabel('ListItem.Plot'),
                    'genre': xbmc.getInfoLabel('ListItem.Genre'),
                    'director': xbmc.getInfoLabel('ListItem.Director'),
                    'tagline': xbmc.getInfoLabel('ListItem.TagLine'),
                    'rating': xbmc.getInfoLabel('ListItem.Rating')

                }
            )

            if subtitle['enable']:
                subtitleList = []
                for i in range(0, len(subtitle['data'])):
                    subtitleList.append(subtitle['data'][i]['src_vtt'])
                item.setSubtitles(subtitleList)
                xbmc.Player().showSubtitles(not doubled)

            item.setPath(qurl)  # Set the User-Agent header when Kodi is streaming.

            if qurl:
                xbmcplugin.setResolvedUrl(PLUGIN_ID, True, item)
            else:
                xbmcplugin.setResolvedUrl(PLUGIN_ID, False, xbmcgui.ListItem())

        elif data['data']['attributes']['watch_action']['type'] == 'pay':
            dialog = xbmcgui.Dialog()
            dialog.ok('خطا در اشتراک', 'برای تماشای فیلم‌ها اشتراک تهیه کنید')
        elif data['data']['attributes']['watch_action']['type'] == 'login':
            dialog = xbmcgui.Dialog()
            dialog.ok('خطا در احراز هویت', 'برای مشاهده فیلم باید وارد شوید')


def build_url(query):
    # Helper function to build a Kodi xbmcgui.ListItem URL string.
    # query -> A dictionary of parameters to put in the item URL.
    return PLUGIN_URL + '?' + urlencode(query)


def make_list_item(label, videoMetadata=None, thumb=None):
    item = xbmcgui.ListItem(label)
    if videoMetadata:
        item.setInfo('video', videoMetadata)
    if thumb:
        item.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb})
    return item


def notification(message, delay=3000, useSound=True):
    xbmcgui.Dialog().notification('', message, xbmcgui.NOTIFICATION_INFO, delay, useSound)
    return None


def action_get_more_movie_plugin(param):
    xbmcplugin.setContent(PLUGIN_ID, 'videos')
    page = int(param.get('page', 1))
    r = requests.get(
        'https://www.filimo.com/api/fa/v1/movie/movie/loadmore/tagid/{tagid}/more_type/infinity/show_serial_parent/1/perpage/40/page/{page}'.format(
            tagid=param['tagid'], page=page), timeout=10, verify=False)
    r = r.json()

    data = r['data']
    for item in data:
        if item["attributes"]['output_type'] == "movie":
            rowdata = item['relationships']['movies']['data']
            break
    else:
        rowdata = []
    include = r['included']

    def _temsGen():
        x = 0
        y = 0
        for j in range(0, len(rowdata)):
            movieid = rowdata[j]['id']
            y = x
            while include[y]['id'] != movieid:
                y = y - 1
            moviedata = include[y]['attributes']
            if x == y:
                x = x + 1
            item = make_list_item(
                moviedata['movie_title'],
                {
                    'title': moviedata['movie_title'],
                    'episode': j  # for ID to detect movie
                },
                moviedata['pic']['movie_img_m']
            )
            itemURL = build_url(
                {
                    'action': 'action_single_movie',
                    'route': moviedata['uid'],
                }
            )
            yield (itemURL, item, True)

    xbmcplugin.addDirectoryItems(PLUGIN_ID, tuple(_temsGen()))
    xbmcplugin.addDirectoryItem(PLUGIN_ID, build_url(
        {'action': "action_get_more_movie_plugin", 'tagid': param['tagid'], 'page': page + 1}),
                                make_list_item("صفحه بعد"), True)
    xbmcplugin.endOfDirectory(PLUGIN_ID)


def get_home_content(params):
    xbmcplugin.setContent(PLUGIN_ID, 'episodes')
    page = int(params.get("page", 1))

    def get_home_menu_slider():
        perpage = 10
        r = requests.get(
            'https://www.filimo.com/api/fa/v1/movie/movie/list/tagid/1/list_perpage/{}/list_offset/{}'.format(perpage,
                                                                                                              perpage * page),
            headers={}, timeout=10, verify=False)
        r = r.json()
        data = r['data']
        include = r['included']
        x = 0
        y = 0
        idCounter = 1
        for i in range(0, len(data)):
            if (data[i]['attributes']['theme'] == "thumbnail"):
                item = make_list_item(data[i]['attributes']['link_text'])
                itemURL = build_url(
                    {
                        'action': 'action_get_more_movie_plugin',
                        'tagid': data[i]['attributes']['tag_id'],
                    }
                )
                yield (itemURL, item, True)

    xbmcplugin.addDirectoryItems(PLUGIN_ID, list(get_home_menu_slider()))

    item = make_list_item("صفحه بعد")
    itemURL = build_url(
        {
            'action': 'get_home_content',
            'page': page + 1,
        }
    )
    xbmcplugin.addDirectoryItem(PLUGIN_ID, itemURL, item, True)
    xbmcplugin.endOfDirectory(PLUGIN_ID)


def main():
    if sys.argv[2] == "":  # called directly from kodi
        action_main_page_plugin()
    else:
        params = dict(parse_qsl(sys.argv[2][1:], keep_blank_values=True))
        globals()[params.get('action')](params)

    return
