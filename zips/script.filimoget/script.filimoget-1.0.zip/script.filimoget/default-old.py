# -*- coding: utf-8 -*-
import sys
import json
import requests
from urllib import urlencode, quote_plus
from urlparse import parse_qsl
import re
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import random
import xml.etree.ElementTree as xmltree
from xml.dom import minidom
reload(sys)
sys.setdefaultencoding('utf8')

# Disable urllib3's "InsecureRequestWarning: Unverified HTTPS request is being made" warnings.
requests.packages.urllib3.disable_warnings(
    requests.packages.urllib3.exceptions.InsecureRequestWarning
)


Includes_HomeTailes_Content_File = ""
Includes_HomeTailes_File = ""
Includes_HomeTailes_Content_File_Temp = ""
Includes_HomeTailes_File_Temp = ""

def copyFile2File(fs,fd):
    for line in fs:
        fd.write(line)


def creatHomeTailes_Files(lastGid):
    global Includes_HomeTailes_File
    global Includes_HomeTailes_Content_File
    global Includes_HomeTailes_File_Temp
    global Includes_HomeTailes_Content_File_Temp
    path = xbmc.translatePath('special://skin/1080i/Includes_HomeTailes.xml')
    Includes_HomeTailes_File = open(path,"w+")

    Includes_HomeTailes_File.write(
        """
<?xml version="1.0" encoding="UTF-8"?>
<includes>
    <include name="HomePageTails">
            <control type="group" id="1900">
            </control>

        """
    )

    path = xbmc.translatePath('special://skin/1080i/Includes_HomeTailes_Content.xml')
    Includes_HomeTailes_Content_File = open(path,"w+")

    Includes_HomeTailes_Content_File.write(
        """
<?xml version="1.0" encoding="UTF-8"?>
<includes>
        """
    )

    Includes_HomeTailes_File_Temp.seek(0)
    copyFile2File(Includes_HomeTailes_File_Temp,Includes_HomeTailes_File)

    Includes_HomeTailes_Content_File_Temp.seek(0)
    copyFile2File(Includes_HomeTailes_Content_File_Temp,Includes_HomeTailes_Content_File)

    Includes_HomeTailes_File.write(
        """
        <control type="group" id="19{0}">
        </control>
    </include>
</includes>
        """.format(format(lastGid,"02d"))
    )
    Includes_HomeTailes_Content_File.write(
        """
</includes>
        """
    )
    Includes_HomeTailes_File.close()
    Includes_HomeTailes_Content_File.close()


def HomeTailes_Temp_Files_Init():
    global Includes_HomeTailes_File_Temp
    global Includes_HomeTailes_Content_File_Temp


    path = xbmc.translatePath('special://skin/1080i/Includes_HomeTailes_Temp.xml')
    Includes_HomeTailes_File_Temp = open(path,"w+")
    path = xbmc.translatePath('special://skin/1080i/Includes_HomeTailes_Content_Temp.xml')
    Includes_HomeTailes_Content_File_Temp = open(path,"w+")

def addToHomeTailes_Files():
    pass

def saveConuntOfTail(num):
    xbmcgui.Window(10000).setProperty('CountOfTail', str(num))

def getConuntOfTail():
    count = xbmcgui.Window(10000).getProperty('CountOfTail')
    return int(count)

def saveLastTileId(num):
    xbmcgui.Window(10000).setProperty('LastTileId', str(num))

def getLastTileId():
    count = xbmcgui.Window(10000).getProperty('LastTileId')
    return int(count)

def HomeTailes_Temp_File_Set_To_Continue():
    global Includes_HomeTailes_File_Temp
    global Includes_HomeTailes_Content_File_Temp
    path = xbmc.translatePath('special://skin/1080i/Includes_HomeTailes_Temp.xml')
    Includes_HomeTailes_File_Temp = open(path,"r+")
    path = xbmc.translatePath('special://skin/1080i/Includes_HomeTailes_Content_Temp.xml')
    Includes_HomeTailes_Content_File_Temp = open(path,"r+")
    Includes_HomeTailes_File_Temp.seek(0,2)
    Includes_HomeTailes_Content_File_Temp.seek(0,2)

def HomeTailes_Add_Row(tailNum,title):
    global Includes_HomeTailes_File_Temp
    Includes_HomeTailes_File_Temp.write(
        """
    <include content="HomeTailObject">
        <param name="id" value="{0}" />
        <param name="nextgid" value="{1}" />
        <param name="pregid" value="{2}" />
        <param name="title" value="{3}" />
    </include>
        """.format(format(tailNum,"02d"),
                   format(tailNum+1,"02d"),
                   format(tailNum-1,"02d"),
                   title.replace(' | ',' ') if title.isnumeric() == False else title + '.'
                  )
        )

def HomeTailes_Content_Start_Row(id):
    global Includes_HomeTailes_Content_File_Temp
    Includes_HomeTailes_Content_File_Temp.write("""
    <include name="TailContent{0}">
    """.format(format(id,"02d")) )

def HomeTailes_Content_Add_Item_Slider(id,name,image,uid):
    global Includes_HomeTailes_Content_File_Temp
    r = requests.get('https://www.filimo.com/_/api/fa/v1/movie/movie/one/uid/' + str(uid), timeout=10, verify=False)      
    try:
        r= r.json()
    except ValueError:
        return
    else:
        showsData=r['data']['attributes']['General']
        plot = showsData['descr']
        title = showsData['title']
        image = image.replace('_app','_desktop_1',1)
        genre = ''
        if showsData['categories'] != None:
            for item in showsData['categories']: genre = genre + item['title'] + ' - '

        director = ''
        if showsData['director'] != None:
            for item in showsData['director']: director = director + item['name'] + ' - '

        tagline = showsData['movie_detail'].replace('-','[COLOR=FFffb000] | [/COLOR]')

        Includes_HomeTailes_Content_File_Temp.write(
            """
            <item id="{0}">
                <label>{1}</label>
                <icon>{2}</icon>
                <onclick>ActivateWindow(videos,plugin://plugin.video.filimo/?action=actionSingleMovie&amp;route={3},return)</onclick>
                <property name="Plot">{4}</property>
                <property name="TagLine">{5}</property>            
                <property name="Director">{6}</property>            
                <property name="Genre">{7}</property>            
            </item>
            """.format(id,
                    title,
                    image,
                    uid,
                    plot,
                    tagline,
                    director[:-2],
                    genre[:-2]
                    )
            )

def HomeTailes_Content_Add_Item(id,name,image,uid):
    global Includes_HomeTailes_Content_File_Temp
    Includes_HomeTailes_Content_File_Temp.write(
        """
        <item id="{0}">
            <label>{1}</label>
            <icon>{2}</icon>
            <onclick>ActivateWindow(videos,plugin://plugin.video.filimo/?action=actionSingleMovie&amp;route={3},return)</onclick>
        </item>
        """.format(id,
                   name,
                   image,
                   uid,
                   
                  )
        )
        
def HomeTailes_Content_End_Row (tagid):
    global Includes_HomeTailes_Content_File_Temp
    Includes_HomeTailes_Content_File_Temp.write(
        """
        <item id="{0}">
            <label>{1}</label>
            <icon>{2}</icon>
            <onclick>ActivateWindow(videos,plugin://plugin.video.filimo/?action=getMoreMovie&amp;tagid={3},return)</onclick>
        </item>
        """.format(99,
                   'فیلم های بیشتر',
                   'diffuse/moremovie.png',
                   tagid
                  )
        )
    Includes_HomeTailes_Content_File_Temp.write("""  </include>""" )
    
def HomeTailes_Content_End_Row_Slider ():
    global Includes_HomeTailes_Content_File_Temp
    Includes_HomeTailes_Content_File_Temp.write("""  </include>""" )

def HomeTailes_Files_Close():
    global Includes_HomeTailes_File
    global Includes_HomeTailes_Content_File
    pass

def updateNewTails(param):
    xbmcgui.Window(10000).setProperty('HomeTailUpdating',"true")
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    r = requests.get('https://www.filimo.com/api/fa/v1/movie/movie/list/tagid/1/list_perpage/5/list_offset/'+ str(getConuntOfTail()), headers={'Cookie':'AuthV1=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE1ODEwODQ0MDYsImFmY24iOiIxNTgxMDMwODczODA4NDUiLCJzdWIiOiIzMDlEQjAyMC1FRkE3LTYwMUItMUYxQi1ENkE4ODREQUEzMjciLCJ0b2tlbiI6IjdiNGI4Yjg3OTU5OGQzYjUyMTlmNzU2M2I3OWI5YWMxIn0.sDo_MTMFGfuMdNhYbm5fEU1KS8ngzLTKG99YxqMPUX4'}, timeout=10, verify=False)     
    r = r.json()
    data = r['data']
    include = r['included']
    x = 0
    y = 0
    HomeTailes_Temp_File_Set_To_Continue()
    c = getConuntOfTail()
    idCounter = getLastTileId()
    focusPossation = getLastTileId()
    for i in range(0,len(data)):
        if (data[i]['attributes']['theme'] == "thumbnail"):
            HomeTailes_Add_Row(idCounter,data[i]['attributes']['link_text'])
            HomeTailes_Content_Start_Row(idCounter)
            idCounter = idCounter + 1
        rowdata = data[i]['relationships']['movies']['data']
        for j in range(0,len(rowdata)):
            movieid = rowdata[j]['id']
            y = x
            while include[y]['id'] != movieid:
                y = y - 1
            moviedata = include[y]['attributes']
            if x == y :
                x = x + 1
            if (data[i]['attributes']['theme'] == "thumbnail"):
                HomeTailes_Content_Add_Item(j+1,moviedata['movie_title'],moviedata['pic']['movie_img_m'],moviedata['uid'])
        if (data[i]['attributes']['theme'] == "thumbnail"):
            HomeTailes_Content_End_Row(data[i]['attributes']['tag_id'])
    saveConuntOfTail(c + len(data))
    saveLastTileId(idCounter)
    creatHomeTailes_Files(idCounter)
    xbmc.executebuiltin("ReloadSkin")
    xbmcgui.Window(10000).setProperty('HomeTailUpdating',"false")
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')


def getHomeContent(params):
    r = requests.get('https://www.filimo.com/api/fa/v1/movie/movie/list/tagid/1/list_perpage/10/list_offset/0', headers={'Cookie':'AuthV1=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE1ODEwODQ0MDYsImFmY24iOiIxNTgxMDMwODczODA4NDUiLCJzdWIiOiIzMDlEQjAyMC1FRkE3LTYwMUItMUYxQi1ENkE4ODREQUEzMjciLCJ0b2tlbiI6IjdiNGI4Yjg3OTU5OGQzYjUyMTlmNzU2M2I3OWI5YWMxIn0.sDo_MTMFGfuMdNhYbm5fEU1KS8ngzLTKG99YxqMPUX4'}, timeout=10, verify=False)     
    r = r.json()
    data = r['data']
    include = r['included']
    x = 0
    y = 0
    HomeTailes_Temp_Files_Init()
    idCounter = 1
    for i in range(0,len(data)):
        rowdata = None
        if (data[i]['attributes']['theme'] == "thumbnail"):
            HomeTailes_Add_Row(idCounter,data[i]['attributes']['link_text'])
            HomeTailes_Content_Start_Row(idCounter)
            idCounter = idCounter + 1
            rowdata = data[i]['relationships']['movies']['data']
        elif data[i]['attributes']['output_type'] == "headerslider":
            HomeTailes_Content_Start_Row(700)
            rowdata = data[i]['relationships']['headersliders']['data']
        if rowdata is None:
            continue
        for j in range(0,len(rowdata)):
            movieid = rowdata[j]['id']
            y = x
            while include[y]['id'] != movieid:
                y = y - 1
            moviedata = include[y]['attributes']
            if x == y :
                x = x + 1
            if (data[i]['attributes']['theme'] == "thumbnail"):
                HomeTailes_Content_Add_Item(j+1,moviedata['movie_title'],moviedata['pic']['movie_img_m'],moviedata['uid'])
            elif data[i]['attributes']['output_type'] == "headerslider" and moviedata['link_type'] == 'movie':
                HomeTailes_Content_Add_Item_Slider(j+1,'',moviedata['cover_desktop'][0],moviedata['link_key'])
        if (data[i]['attributes']['theme'] == "thumbnail"):
            HomeTailes_Content_End_Row(data[i]['attributes']['tag_id'])
        elif data[i]['attributes']['output_type'] == "headerslider":
            HomeTailes_Content_End_Row_Slider()

    creatHomeTailes_Files(idCounter)
    saveConuntOfTail(len(data))
    saveLastTileId(idCounter)
    xbmcgui.Window(10000).setProperty('HomeTailInited',"true")
    xbmc.executebuiltin("ReloadSkin")
    xbmcgui.Window(10000).setProperty('HomeTailUpdating',"false")


def addHomeTailObject(parent,parameters):
    homeTailObject = xmltree.SubElement( parent, "include" )
    homeTailObject.set("content","HomeTailObject")
    for key,value in parameters.items():
        param = xmltree.SubElement( homeTailObject, "param" )
        param.set("name",key)
        param.set("value",str(value))

def addItemToTailContent(parent,id,properties={},**kwargs):
    item = xmltree.SubElement(parent, "item" )
    item.set('id',str(id) )

    for key,value in kwargs.items():
        insideitem = xmltree.SubElement( item, key )
        insideitem.text = value

    for key,value in properties.items():
        insideitem = xmltree.SubElement( item, "property" )
        insideitem.set("name",key)
        insideitem.text = value



def addItemToTailContentBigSlider(parent,id,name,image,uid):
    global Includes_HomeTailes_Content_File_Temp
    r = requests.get('https://www.filimo.com/_/api/fa/v1/movie/movie/one/uid/' + str(uid), timeout=10, verify=False)      
    try:
        r= r.json()
    except ValueError:
        return
    else:
        showsData=r['data']['attributes']['General']
        plot = showsData['descr']
        title = showsData['title']
        image = image.replace('_app','_desktop_1',1)
        genre = ''
        if showsData['categories'] != None:
            for item in showsData['categories']: genre = genre + item['title'] + ' - '

        director = ''
        if showsData['director'] != None:
            for item in showsData['director']: director = director + item['name'] + ' - '

        tagline = showsData['movie_detail'].replace('-','[COLOR=FFffb000] | [/COLOR]')

        addItemToTailContent(parent,id,
            label=title,
            icon=image,
            onclick="ActivateWindow(videos,plugin://plugin.video.filimo/?action=actionSingleMovie&amp;route={},return)".format(uid),
            properties={"Plot":plot,"TagLine":tagline,"Director":director[:-2],"Genre":genre[:-2]}
            )


def getHomeContentNew(params):
    tail_root = xmltree.ElementTree(xmltree.Element("includes")).getroot()
    HomeTailObjects = xmltree.SubElement( tail_root, "include" )
    HomeTailObjects.set( "name", "HomePageTails" )

    addGroupControlWithId(HomeTailObjects,1900)

    tail_content_root = xmltree.ElementTree(xmltree.Element("includes")).getroot()

    r = requests.get('https://www.filimo.com/api/fa/v1/movie/movie/list/tagid/1/list_perpage/10/list_offset/0', timeout=10, verify=False)     
    r = r.json()
    data = r['data']
    include = r['included']
    x = 0
    y = 0
    idCounter = 1
    for i in range(0,len(data)):
        rowdata = None
        if (data[i]['attributes']['theme'] == "thumbnail"):
            title = data[i]['attributes']['link_text']
            addHomeTailObject(HomeTailObjects,parameters={
                                            "id":format(idCounter,"02d"),
                                            "nextgid":format(idCounter+1,"02d"),
                                            "pregid":format(idCounter-1,"02d"),
                                            "title":title.replace(' | ',' ') if not title.isnumeric() else title + '.'
                                             }
                                        )

            rowdata = data[i]['relationships']['movies']['data']
            tail_content = xmltree.SubElement(tail_content_root, "include" )
            tail_content.set( "name", "TailContent{}".format(format(idCounter,'02d')) )
            idCounter = idCounter + 1

        elif data[i]['attributes']['output_type'] == "headerslider":
            BigSlider = xmltree.SubElement(tail_content_root, "include" ) # We consider that only one BigSlider exist in Filimo Api
            BigSlider.set( "name", "BigSlider" )
            rowdata = data[i]['relationships']['headersliders']['data']

        if rowdata is None:
            continue
        
        for j in range(0,len(rowdata)):
            movieid = rowdata[j]['id']
            y = x
            while include[y]['id'] != movieid:
                y = y - 1
            moviedata = include[y]['attributes']
            if x == y :
                x = x + 1
            if (data[i]['attributes']['theme'] == "thumbnail"):
                addItemToTailContent(tail_content,j+1,
                                    label=moviedata['movie_title'],
                                    icon=moviedata['pic']['movie_img_m'],
                                    onclick="ActivateWindow(videos,plugin://plugin.video.filimo/?action=actionSingleMovie&amp;route={},return)".format(moviedata['uid'])
                                    )
            elif data[i]['attributes']['output_type'] == "headerslider" and moviedata['link_type'] == 'movie':
                addItemToTailContentBigSlider(BigSlider,j+1,'',moviedata['cover_desktop'][0],moviedata['link_key'])

    addGroupControlWithId(HomeTailObjects,idCounter+1900)


    write_hometailes_file(tail_root)
    write_hometailes_content_file(tail_content_root)
    saveConuntOfTail(len(data))
    saveLastTileId(idCounter)
    xbmcgui.Window(10000).setProperty('HomeTailInited',"true")
    xbmc.executebuiltin("ReloadSkin")
    xbmcgui.Window(10000).setProperty('HomeTailUpdating',"false")


def saveTailContentTree(xmlroot):
    xmlstr = xmltree.tostring(xmlroot, encoding='utf-8', method='xml')
    xbmcgui.Window(10000).setProperty('TailContentTree',xmlstr)

def saveTailTree(xmlroot):
    xmlstr = xmltree.tostring(xmlroot, encoding='utf-8', method='xml')
    xbmcgui.Window(10000).setProperty('TailTree',xmlstr)


def getHomeContentandUpdate(params):

    tail_content_root = xbmcgui.Window(10000).getProperty('TailContentTree')

    if not tail_content_root:
        first_run = True
        tail_root = xmltree.ElementTree(xmltree.Element("includes")).getroot()
        HomeTailObjects = xmltree.SubElement( tail_root, "include" )
        HomeTailObjects.set( "name", "HomePageTails" )
        addGroupControlWithId(HomeTailObjects,1900)
        tail_content_root = xmltree.ElementTree(xmltree.Element("includes")).getroot()
        offset = 0
        idCounter = 1
        perpage = 10
    else:
        tail_content_root = xmltree.fromstring(tail_content_root)
        tail_root = xmltree.fromstring(xbmcgui.Window(10000).getProperty('TailTree'))
        HomeTailObjects = tail_root.find("include")
        offset = getConuntOfTail()
        idCounter = getLastTileId()
        first_run = False
        perpage = 5
        xbmcgui.Window(10000).setProperty('HomeTailUpdating',"true")
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')


    r = requests.get('https://www.filimo.com/api/fa/v1/movie/movie/list/tagid/1/list_perpage/{}/list_offset/{}'.format(perpage,offset), timeout=10, verify=False)     
    # r = requests.get('https://www.filimo.com/api/fa/v1/movie/movie/list/tagid/1/list_perpage/10/list_offset/0', timeout=10, verify=False)     
    r = r.json()
    data = r['data']
    include = r['included']
    x = 0
    y = 0

    for i in range(0,len(data)):
        rowdata = None
        if (data[i]['attributes']['theme'] == "thumbnail"):
            title = data[i]['attributes']['link_text']
            addHomeTailObject(HomeTailObjects,parameters={
                                            "id":format(idCounter,"02d"),
                                            "nextgid":format(idCounter+1,"02d"),
                                            "pregid":format(idCounter-1,"02d"),
                                            "title":title.replace(' | ',' ') if not title.isnumeric() else title + '.'
                                             }
                                        )

            rowdata = data[i]['relationships']['movies']['data']
            tail_content = xmltree.SubElement(tail_content_root, "include" )
            tail_content.set( "name", "TailContent{}".format(format(idCounter,'02d')) )
            idCounter = idCounter + 1

        elif data[i]['attributes']['output_type'] == "headerslider":
            BigSlider = xmltree.SubElement(tail_content_root, "include" ) # We consider that only one BigSlider exist in Filimo Api
            BigSlider.set( "name", "BigSlider" )
            rowdata = data[i]['relationships']['headersliders']['data']

        if rowdata is None:
            continue
        
        for j in range(0,len(rowdata)):
            movieid = rowdata[j]['id']
            y = x
            while include[y]['id'] != movieid:
                y = y - 1
            moviedata = include[y]['attributes']
            if x == y :
                x = x + 1
            if (data[i]['attributes']['theme'] == "thumbnail"):
                addItemToTailContent(tail_content,j+1,
                                    label=moviedata['movie_title'],
                                    icon=moviedata['pic']['movie_img_m'],
                                    onclick="ActivateWindow(videos,plugin://plugin.video.filimo/?action=actionSingleMovie&amp;route={},return)".format(moviedata['uid'])
                                    )
            elif data[i]['attributes']['output_type'] == "headerslider" and moviedata['link_type'] == 'movie':
                addItemToTailContentBigSlider(BigSlider,j+1,'',moviedata['cover_desktop'][0],moviedata['link_key'])
        if (data[i]['attributes']['theme'] == "thumbnail"):
            addItemToTailContent(tail_content,99,
                                    label="فیلم های بیشتر",
                                    icon='diffuse/moremovie.png',
                                    onclick="ActivateWindow(videos,plugin://plugin.video.filimo/?action=action_get_more_movie_plugin&amp;tagid={},return)".format(data[i]['attributes']['tag_id'])
                                    )
    saveTailTree(tail_root)
    saveTailContentTree(tail_content_root)
    addGroupControlWithId(HomeTailObjects,idCounter+1900)


    write_hometailes_file(tail_root)
    write_hometailes_content_file(tail_content_root)
    saveConuntOfTail(offset+len(data))
    saveLastTileId(idCounter)

    if first_run:
        xbmcgui.Window(10000).setProperty('HomeTailInited',"true")
        xbmc.executebuiltin("ReloadSkin")
        xbmcgui.Window(10000).setProperty('HomeTailUpdating',"false")
    else:
        xbmc.executebuiltin("ReloadSkin")
        xbmcgui.Window(10000).setProperty('HomeTailUpdating',"false")
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')



def addGroupControlWithId(parent,id):
    control = xmltree.SubElement( parent, "control" )
    control.set("type","group")
    control.set("id",str(id))



def write_xml_to_file(xmlroot,path):
    xmlstr = xmltree.tostring(xmlroot, encoding='utf-8', method='xml')
    xmlstr = minidom.parseString(xmlstr).toprettyxml(indent="   ",encoding='utf-8')
    with open(path,'wb') as f:
        f.write(xmlstr)
    
def write_hometailes_file(xmlroot):
    path = xbmc.translatePath('special://skin/1080i/Includes_HomeTailes.xml')
    write_xml_to_file(xmlroot,path)

def write_hometailes_content_file(xmlroot):
    path = xbmc.translatePath('special://skin/1080i/Includes_HomeTailes_Content.xml')
    write_xml_to_file(xmlroot,path)


def main():
    params = dict(parse_qsl(sys.argv[1], keep_blank_values=True))        
    globals()[params.get('func', 'getHomeContentandUpdate')](params) # Call the action function, defaults to actionShowsMenu().

main()