# -*- coding: utf-8 -*-
# Filimo Kodi Plugin
# 2021 January  01 (c) Ali Fallah

import sys
import json
import requests
from urllib import urlencode, quote_plus
from urlparse import parse_qsl
import re
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import random
import xml.etree.ElementTree as xmltree
from xml.dom import minidom
reload(sys)
sys.setdefaultencoding('utf8')

# Disable urllib3's "InsecureRequestWarning: Unverified HTTPS request is being made" warnings.
requests.packages.urllib3.disable_warnings(
    requests.packages.urllib3.exceptions.InsecureRequestWarning
)


def addGroupControlWithId(parent,id):
    control = xmltree.SubElement( parent, "control" )
    control.set("type","group")
    control.set("id",str(id))

def write_xml_to_file(xmlroot,path):
    xmlstr = xmltree.tostring(xmlroot, encoding='utf-8', method='xml')
    xmlstr = minidom.parseString(xmlstr).toprettyxml(indent="   ",encoding='utf-8')
    with open(path,'wb') as f:
        f.write(xmlstr)
    
def write_hometailes_file(xmlroot):
    path = xbmc.translatePath('special://skin/1080i/Includes_HomeTailes.xml')
    write_xml_to_file(xmlroot,path)

def write_hometailes_content_file(xmlroot):
    path = xbmc.translatePath('special://skin/1080i/Includes_HomeTailes_Content.xml')
    write_xml_to_file(xmlroot,path)

def saveConuntOfTail(num):
    xbmcgui.Window(10000).setProperty('CountOfTail', str(num))

def getConuntOfTail():
    count = xbmcgui.Window(10000).getProperty('CountOfTail')
    return int(count)

def saveLastTileId(num):
    xbmcgui.Window(10000).setProperty('LastTileId', str(num))

def getLastTileId():
    count = xbmcgui.Window(10000).getProperty('LastTileId')
    return int(count)

def saveTailContentTree(xmlroot):
    xmlstr = xmltree.tostring(xmlroot, encoding='utf-8', method='xml')
    xbmcgui.Window(10000).setProperty('TailContentTree',xmlstr)

def saveTailTree(xmlroot):
    xmlstr = xmltree.tostring(xmlroot, encoding='utf-8', method='xml')
    xbmcgui.Window(10000).setProperty('TailTree',xmlstr)


def addHomeTailObject(parent,parameters):
    homeTailObject = xmltree.SubElement( parent, "include" )
    homeTailObject.set("content","HomeTailObject")
    for key,value in parameters.items():
        param = xmltree.SubElement( homeTailObject, "param" )
        param.set("name",key)
        param.set("value",str(value))

def addItemToTailContent(parent,id,properties={},**kwargs):
    item = xmltree.SubElement(parent, "item" )
    item.set('id',str(id) )

    for key,value in kwargs.items():
        insideitem = xmltree.SubElement( item, key )
        insideitem.text = value

    for key,value in properties.items():
        insideitem = xmltree.SubElement( item, "property" )
        insideitem.set("name",key)
        insideitem.text = value

def addItemToTailContentBigSlider(parent,id,name,image,uid):
    global Includes_HomeTailes_Content_File_Temp
    r = requests.get('https://www.filimo.com/_/api/fa/v1/movie/movie/one/uid/' + str(uid), timeout=10, verify=False)      
    try:
        r= r.json()
    except ValueError:
        return
    else:
        showsData=r['data']['attributes']['General']
        plot = showsData['descr']
        title = showsData['title']
        image = image.replace('_app','_desktop_1',1)
        genre = ''
        if showsData['categories'] != None:
            for item in showsData['categories']: genre = genre + item['title'] + ' - '

        director = ''
        if showsData['director'] != None:
            for item in showsData['director']: director = director + item['name'] + ' - '

        tagline = showsData['movie_detail'].replace('-','[COLOR=FFffb000] | [/COLOR]')

        addItemToTailContent(parent,id,
            label=title,
            icon=image,
            onclick="ActivateWindow(videos,plugin://plugin.video.filimo/?action=action_single_movie&amp;route={},return)".format(uid),
            properties={"Plot":plot,"TagLine":tagline,"Director":director[:-2],"Genre":genre[:-2]}
            )

def getContentFromFilimo(idCounter,offset,perpage,HomeTailObjects,HomeTailItems):
    r = requests.get('https://www.filimo.com/api/fa/v1/movie/movie/list/tagid/1/list_perpage/{}/list_offset/{}'.format(perpage,offset), timeout=10, verify=False)     
    r = r.json()
    data = r['data']
    include = r['included']
    x = 0
    y = 0

    for i in range(0,len(data)):
        rowdata = None
        if (data[i]['attributes']['theme'] == "thumbnail"):
            title = data[i]['attributes']['link_text']
            addHomeTailObject(HomeTailObjects,parameters={
                                            "id":format(idCounter,"02d"),
                                            "nextgid":format(idCounter+1,"02d"),
                                            "pregid":format(idCounter-1,"02d"),
                                            "title":title.replace(' | ',' ') if not title.isnumeric() else title + '.'
                                             }
                                        )

            rowdata = data[i]['relationships']['movies']['data']
            tail_content = xmltree.SubElement(HomeTailItems, "include" )
            tail_content.set( "name", "TailContent{}".format(format(idCounter,'02d')) )
            idCounter = idCounter + 1

        elif data[i]['attributes']['output_type'] == "headerslider":
            BigSlider = xmltree.SubElement(HomeTailItems, "include" ) # We consider that only one BigSlider exist in Filimo Api
            BigSlider.set( "name", "BigSlider" )
            rowdata = data[i]['relationships']['headersliders']['data']

        if rowdata is None:
            continue
        
        for j in range(0,len(rowdata)):
            movieid = rowdata[j]['id']
            y = x
            while include[y]['id'] != movieid:
                y = y - 1
            moviedata = include[y]['attributes']
            if x == y :
                x = x + 1
            if (data[i]['attributes']['theme'] == "thumbnail"):
                addItemToTailContent(tail_content,j+1,
                                    label=moviedata['movie_title'],
                                    icon=moviedata['pic']['movie_img_m'],
                                    onclick="ActivateWindow(videos,plugin://plugin.video.filimo/?action=action_single_movie&amp;route={},return)".format(moviedata['uid'])
                                    )
            elif data[i]['attributes']['output_type'] == "headerslider" and moviedata['link_type'] == 'movie':
                addItemToTailContentBigSlider(BigSlider,j+1,'',moviedata['cover_desktop'][0],moviedata['link_key'])
        if (data[i]['attributes']['theme'] == "thumbnail"):
            addItemToTailContent(tail_content,99,
                                    label="فیلم های بیشتر",
                                    icon='diffuse/moremovie.png',
                                    onclick="ActivateWindow(videos,plugin://plugin.video.filimo/?action=action_get_more_movie_plugin&amp;tagid={},return)".format(data[i]['attributes']['tag_id'])
                                    )
    return idCounter,offset+len(data) # return id and offset

def getHomeContentandUpdate(params):

    tail_content_root = xbmcgui.Window(10000).getProperty('TailContentTree')
    if not tail_content_root:
        tail_root = xmltree.ElementTree(xmltree.Element("includes")).getroot()
        HomeTailObjects = xmltree.SubElement( tail_root, "include" )
        HomeTailObjects.set( "name", "HomePageTails" )
        addGroupControlWithId(HomeTailObjects,1900)
        tail_content_root = xmltree.ElementTree(xmltree.Element("includes")).getroot()
        idCounter,offset = getContentFromFilimo(1,0,10,HomeTailObjects,tail_content_root)

        xbmcgui.Window(10000).setProperty('HomeTailInited',"true")
        xbmc.executebuiltin("ReloadSkin")
        xbmcgui.Window(10000).setProperty('HomeTailUpdating',"false")

    else:
        tail_content_root = xmltree.fromstring(tail_content_root)
        tail_root = xmltree.fromstring(xbmcgui.Window(10000).getProperty('TailTree'))
        HomeTailObjects = tail_root.find("include")
        offset = getConuntOfTail()
        idCounter = getLastTileId()
        xbmcgui.Window(10000).setProperty('HomeTailUpdating',"true")
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        idCounter,offset =  getContentFromFilimo(idCounter,offset,5,HomeTailObjects,tail_content_root)



        xbmc.executebuiltin("ReloadSkin")
        xbmcgui.Window(10000).setProperty('HomeTailUpdating',"false")
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

    saveTailTree(tail_root)
    saveTailContentTree(tail_content_root)
    saveConuntOfTail(offset)
    saveLastTileId(idCounter)

    addGroupControlWithId(HomeTailObjects,idCounter+1900)
    write_hometailes_file(tail_root)
    write_hometailes_content_file(tail_content_root)


def writeAndSave(HomeTailObjects,tail_root,tail_content_root,idCounter,offset):
    saveTailTree(tail_root)
    saveTailContentTree(tail_content_root)
    saveConuntOfTail(offset)
    saveLastTileId(idCounter)
    addGroupControlWithId(HomeTailObjects,idCounter+1900)
    write_hometailes_file(tail_root)
    write_hometailes_content_file(tail_content_root)

def getHomeContent(params):
    tail_root = xmltree.ElementTree(xmltree.Element("includes")).getroot()
    HomeTailObjects = xmltree.SubElement( tail_root, "include" )
    HomeTailObjects.set( "name", "HomePageTails" )
    addGroupControlWithId(HomeTailObjects,1900)
    tail_content_root = xmltree.ElementTree(xmltree.Element("includes")).getroot()
    idCounter,offset = getContentFromFilimo(1,0,10,HomeTailObjects,tail_content_root)
    writeAndSave(HomeTailObjects,tail_root,tail_content_root,idCounter,offset)
    xbmcgui.Window(10000).setProperty('HomeTailInited',"true")
    xbmc.executebuiltin("ReloadSkin")
    xbmcgui.Window(10000).setProperty('HomeTailUpdating',"false")

def updateHomeContent(params):
    tail_content_root = xbmcgui.Window(10000).getProperty('TailContentTree')
    tail_content_root = xmltree.fromstring(tail_content_root)
    tail_root = xmltree.fromstring(xbmcgui.Window(10000).getProperty('TailTree'))
    HomeTailObjects = tail_root.find("include")
    offset = getConuntOfTail()
    idCounter = getLastTileId()
    xbmcgui.Window(10000).setProperty('HomeTailUpdating',"true")
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    idCounter,offset =  getContentFromFilimo(idCounter,offset,5,HomeTailObjects,tail_content_root)
    writeAndSave(HomeTailObjects,tail_root,tail_content_root,idCounter,offset)
    xbmc.executebuiltin("ReloadSkin")
    xbmcgui.Window(10000).setProperty('HomeTailUpdating',"false")
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')


def main():
    params = dict(parse_qsl(sys.argv[1], keep_blank_values=True))        
    globals()[params.get('func', 'getHomeContent')](params) # Call the action function, defaults to actionShowsMenu().

main()